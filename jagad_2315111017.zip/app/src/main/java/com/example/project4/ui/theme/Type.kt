package com.example.project4.ui.theme

import androidx.compose.material3.Typography

// Gunakan Typography default Material3
val Typography = Typography()
